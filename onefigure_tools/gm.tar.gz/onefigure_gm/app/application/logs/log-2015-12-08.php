<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-08 15:30:10 --> selectAchievementInfo
ERROR - 2015-12-08 15:30:10 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:30:10 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 696
ERROR - 2015-12-08 15:43:49 --> selectAchievementInfo
ERROR - 2015-12-08 15:43:49 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:43:49 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 729
ERROR - 2015-12-08 15:48:20 --> selectAchievementInfo
ERROR - 2015-12-08 15:48:20 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:48:20 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 728
ERROR - 2015-12-08 15:50:08 --> selectAchievementInfo
ERROR - 2015-12-08 15:50:08 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:50:08 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 728
ERROR - 2015-12-08 15:54:05 --> selectAchievementInfo
ERROR - 2015-12-08 15:54:06 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:54:06 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 698
ERROR - 2015-12-08 15:57:17 --> selectAchievementInfo
ERROR - 2015-12-08 15:57:17 --> http://gamepms.sky-mobi.com/download/images/docs/ofdp/v22/27.csv
ERROR - 2015-12-08 15:57:17 --> Severity: Notice  --> Undefined variable: current_month_date /nfsroot/html_onefigure/app/application/views/user/view.php 698
