<iframe name="blank_frame" src="about:blank" width="0" height="0" frameborder="0" />
</body>
</html>