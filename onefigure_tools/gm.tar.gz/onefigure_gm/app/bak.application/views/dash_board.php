<?php
$date_array = array();
for ($i=-4; $i<=0; $i++) {
    $date_array[] = date('m-d', strtotime($i . ' days'));
}
?>

<table class="table">
  <col width="10%" />
  <col width="15%" />
  <col width="15%" />
  <col width="15%" />
  <col width="15%" />
  <col width="15%" />
  <col width="15%" />

 

  <tbody>
    



  </tbody>
</table>

