<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['base_url'] = 'http://example.com/index.php/test/page/';
$config['total_rows'] = 200;
$config['per_page'] = 20;
