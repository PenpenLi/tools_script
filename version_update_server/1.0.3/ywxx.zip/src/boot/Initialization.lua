local Initialization = {}

function Initialization:start()
    require("common.HelperFunc")
    require ("network.Http")
end

--require "lfs"
--local path = lfs.currentdir()
--cclog("[test-lfs]"..path)

return Initialization
