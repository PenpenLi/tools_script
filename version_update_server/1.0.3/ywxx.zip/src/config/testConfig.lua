local testConfig = {
    ["10000"] = {
        ["name"] = "chris",
        ["age"] = 18,
        ["sex"] = "man"
    },
    ["10001"] = {
        ["name"] = "jack",
        ["age"] = 18,
        ["sex"] = "woman"
    }
}

return testConfig


