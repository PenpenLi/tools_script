
require "Cocos2d"

-- cclog
cclog = function(...)
    print(string.format(...))
end

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
    return msg
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    
    --Game engine configure
    cc.Director:getInstance():setAnimationInterval(1.0/30)
    cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(960, 640, cc.ResolutionPolicy.FIXED_HEIGHT)
    
    --first scene 
    --local scene = require("scene.home.HomeScene"):create()
    local scene = require("src.boot.UpdateScene"):create()

    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(scene)
    else
        cc.Director:getInstance():runWithScene(scene)
    end
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
