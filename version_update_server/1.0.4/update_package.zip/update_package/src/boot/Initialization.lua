local Initialization = {}

local function addSearchPath(path)
    local updateDir = cc.FileUtils:getInstance():getWritablePath().."update_package"
    if cc.FileUtils:getInstance():isFileExist(updateDir) then
        cc.FileUtils:getInstance():addSearchPath(updateDir.."/"..path)
        cclog("Add update search path:"..updateDir.."/"..path)
    end
    cc.FileUtils:getInstance():addSearchPath(path)
end

function Initialization:start()
    --1. add search path for LUA code and image resource
    addSearchPath("src")
    addSearchPath("src/boot")
    addSearchPath("res")
    addSearchPath("res/image")
    addSearchPath("res/image/ui")
    addSearchPath("res/image/ui/home")
    
    --2. require module
    require ("common.HelperFunc")
    require ("network.Http")
end

cclog("--------------this is a updated version-------------------")

--require "lfs"
--local path = lfs.currentdir()
--cclog("[test-lfs]"..path)

return Initialization
