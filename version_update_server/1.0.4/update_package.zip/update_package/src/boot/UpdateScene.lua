require "Cocos2d"
require "lfs"
require ("json")
require "src.common.HelperFunc"

local NEED_UPDATE = true
local server = "http://127.0.0.1/version/versionList.php"

--currVersion 1.1.1, 1.1 is bigVersion, 1 is smallVersion
--key:"current-version-code" is defined in AssetManager in cpp
local currVersion = cc.UserDefault:getInstance():getStringForKey("current-version-code")
local bigVersion = "1.0"

local UpdateScene = class("UpdateScene", function()
    return cc.Scene:create()
end)

function UpdateScene:create()
    local scene = UpdateScene.new()
    scene:initM()
    return scene
end

function UpdateScene:ctor()
end

function UpdateScene:onEnter()
    self:getNewestVersion()
end

function UpdateScene:onExit()
    self.assetsManager:release()
    self.assetsManager = nil
end

function UpdateScene:initM()
    local function onNodeEvent(event)
        if event == "enter" then self:onEnter()
        elseif event == "exit" then self:onExit() end
    end
    self:registerScriptHandler(onNodeEvent)
    
    self.path = cc.FileUtils:getInstance():getWritablePath()
    
    if string.len(currVersion) == 0 then
        currVersion = bigVersion..".0"
    end
    local strs = string.split(currVersion, ".")
    self.currVersion = currVersion
    self.smallVersion = tonumber(strs[3])
    self.bigVersion = strs[1].."."..strs[2]
    
    --big version upate
    if self.bigversion ~= bigVersion then
        --self:delAllFilesInDirectory(self.path)
    end
end

function UpdateScene:createDownPath(path)
    if not self:checkDirOK(path) then
        print("update or create dictionary failed, start game")
        self:noUpdateStart()
        return
    else
        print("update or create dictionary succefully")
    end
end

function UpdateScene:checkDirOK(path)
    local oldpath = lfs.currentdir()
    if lfs.chdir(path) then
        lfs.chdir(oldpath)
        return true
    end
    if lfs.mkdir(path) then
        return true
    end
end

function UpdateScene:delAllFilesInDirectory(path)
    if false == cc.FileUtils:getInstance():isFileExist(path) then
        return
    end
    
    for file in lfs.dir(path) do
      if file ~= "." and file ~= ".." then
          local f = path..'/'..file
          local attr = lfs.attributes (f)
          assert (type(attr) == "table")
          if attr.mode == "directory" then
              self:delAllFilesInDirectory (f)
          else
              os.remove(f)
          end
      end
    end
end

function UpdateScene:startNextScene()
    local updateDir = cc.FileUtils:getInstance():getWritablePath().."update_package"
    if cc.FileUtils:getInstance():isFileExist(updateDir) then
        cc.FileUtils:getInstance():addSearchPath(updateDir.."/src")
        cc.FileUtils:getInstance():addSearchPath(updateDir.."/res")
    end
    cc.FileUtils:getInstance():addSearchPath("src")
    cc.FileUtils:getInstance():addSearchPath("res")
    
    local Initialization = require("boot.Initialization")
    Initialization:start()
    
    cclog("[UpdateScene]enter HomeScene now.")
    local HomeScene = require "scene.home.HomeScene"
    cc.Director:getInstance():replaceScene(HomeScene:create())
end

function UpdateScene:downIndexedVersion()
    self.nowDownIndex = self.nowDownIndex or 1
    local versionUrl = self.needDownVersionList[self.nowDownIndex].versionUrl
    local packageUrl = self.needDownVersionList[self.nowDownIndex].packageUrl
    cclog("[UpdateScene]update version:"..versionUrl..", "..packageUrl)
    
    if self.nowDownIndex == 1 then
        self.assetsManager = cc.AssetsManager:new(packageUrl, versionUrl, self.path) --资源包路径，版本号路径，存储路径
        self.assetsManager:retain()
        local function onError(errorCode)
            --cclog("[UpdateScene]assets onError:"..errorCode)
            if errorCode == 2 then end
        end
        local function onProgress(percent) end
        local function onSuccess() self:downNextVersion() end
        
        self.assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
        self.assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
        self.assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS)
        self.assetsManager:setConnectionTimeout(10)
    else
        self.assetsManager:setVersionFileUrl(versionUrl)
        self.assetsManager:setPackageUrl(packageUrl)
    end
    
    if self.assetsManager:checkUpdate() then
        self.assetsManager:update()
    else
        self:downNextVersion() 
    end
end

function UpdateScene:getNewestVersion()
    if not NEED_UPDATE then
        cclog("[UpdateScene]current is debug version, no need for updating")
        self:startNextScene()
        return
    end
    
    local http = cc.XMLHttpRequest:new()    
    local function httpCallback()
        local result = {}
        local responseStr = http.response
        cclog("--[Http_Recv]--"..responseStr)
        if responseStr == nil or responseStr == "" then
            result.err = 1
            return
        end        
        local needDownVersions = json.decode(responseStr)
        if needDownVersions.code == 200 then
            self.needDownVersionList = needDownVersions.list         
            if #self.needDownVersionList > 0 then
                self:downIndexedVersion()
            end
        else
            --self:noUpdateStart()            
        end
    end

    http.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    local url = server.."?clientVersion="..self.currVersion
    cclog("[UpdateScene]getNewestVersion url:"..url)
    http:open("GET", url)
    http:registerScriptHandler(httpCallback)
    http:send()
end

function UpdateScene:downNextVersion()
    if self.nowDownIndex < #self.needDownVersionList then
        self.nowDownIndex = self.nowDownIndex + 1
        self:downIndexedVersion()
    else
        cclog("[UpdateScene]update succes")
        self:startNextScene()
    end
end

return UpdateScene
