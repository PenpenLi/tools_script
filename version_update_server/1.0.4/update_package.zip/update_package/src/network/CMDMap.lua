local function Login_handler(data)
    cclog("[CMDMap]Login_handler called")
    local Player = require "data.Player"
    Player:setData(data.player)
end

local function Default_handler(data)
    cclog("[CMDMap]Default_handler called")
end

------------------------------CMD map table-------------------------------------
local CMDMap = {
    -----From LandProto.proto-----
    ["Login"] = {["cmdId"]=101,["cmdHandler"]=Login_handler},
    ["RoleList"] = {["cmdId"]=103, ["cmdHandler"]=Default_handler},
    ["CreateRole"] = {["cmdId"]=105, ["cmdHandler"]=Default_handler},
    ["DeleteRole"] = {["cmdId"]=107, ["cmdHandler"]=Default_handler},
    ["RandomName"] = {["cmdId"]=109, ["cmdHandler"]=Default_handler},
    ["RolerReconnection"] = {["cmdId"]=111, ["cmdHandler"]=Default_handler},
    ["RolerGoBack"] = {["cmdId"]=113, ["cmdHandler"]=Default_handler},
}

return CMDMap
