require "Cocos2d"

local HomeCityLayer = class("HomeCityLayer", function()
    return cc.Layer:create()
end)

function HomeCityLayer:create()
    local layer = HomeCityLayer.new()
    layer:initM()
    return layer
end

function HomeCityLayer:ctor()
end

function HomeCityLayer:onEnter()
    cclog("onEnter")
end

function HomeCityLayer:onExit()
    cclog("onExit")
end

function HomeCityLayer:initM()
    local function onNodeEvent(event)
        if event == "enter" then self:onEnter() 
        elseif event == "exit" then self:onExit() end
    end
    self:registerScriptHandler(onNodeEvent)

    self.rootNode = ccs.GUIReader:getInstance():widgetFromBinaryFile("image/ui/home/HomeCityLayer.csb")
    self:addChild(self.rootNode)
    
    --get control reference
    local function touchEventHandler(sender, event)
        self:handleTouchEvent(sender, event)
    end
    self.scrollView = ccui.Helper:seekWidgetByName(self.rootNode, "ScrollView")
    self.scrollView:addTouchEventListener(touchEventHandler)
    
    local parallaxNode = cc.ParallaxNode:create()
    parallaxNode:setAnchorPoint(0, 0)
    local bg1 = cc.Sprite:create("image/bg/home_bg1.png") --jinjing
    local bg2 = cc.Sprite:create("image/bg/home_bg2.png") --zhongjing
    local bg3 = cc.Sprite:create("image/bg/home_bg3.png") --far
    bg1:setAnchorPoint(0, 0)
    bg2:setAnchorPoint(0, 0)
    bg3:setAnchorPoint(0, 0)
    parallaxNode:addChild(bg3,0, cc.p(0.3,1.0), cc.p(0,0))
    parallaxNode:addChild(bg2,0, cc.p(0.6,1.0), cc.p(0,0))
    parallaxNode:addChild(bg1,0, cc.p(1.0,1.0), cc.p(0,0))
    self.scrollView:addChild(parallaxNode, -1)
end

function HomeCityLayer:handleTouchEvent(sender, event)
    if sender == nil then
        cclog("[ERR]unknown sender")
    elseif sender == self.scrollView and event == cc.EventCode.ENDED then
        cclog("scrollView OK!!!")
    else
        --cclog("unkonwn sender") 
    end
end

return HomeCityLayer

