require "Cocos2d"

local HomeCityLayer = require "scene.home.HomeCityLayer"
local HomeUILayer = require "scene.home.HomeUILayer"

local HomeScene = class("HomeScene", function()
    return cc.Scene:create()
end)

function HomeScene:create()
    local scene = HomeScene.new()
    scene:initM()
    return scene
end

function HomeScene:ctor()
end

function HomeScene:initM()
    self.homeCityLayer = HomeCityLayer:create()
    self.homeUILayer = HomeUILayer:create()
    self:addChild(self.homeCityLayer)
    self:addChild(self.homeUILayer)
end

return HomeScene
