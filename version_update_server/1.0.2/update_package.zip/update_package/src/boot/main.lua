
require "Cocos2d"

-- cclog
cclog = function(...)
    print(string.format(...))
end

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
    return msg
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    
    --Game engine configure
    cc.Director:getInstance():setAnimationInterval(1.0/30)
    cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(960, 640, cc.ResolutionPolicy.FIXED_HEIGHT)
    
    --add search path for LUA code and image resource
    cc.FileUtils:getInstance():addSearchPath("src")
    cc.FileUtils:getInstance():addSearchPath("src/boot")
    cc.FileUtils:getInstance():addSearchPath("res")
    cc.FileUtils:getInstance():addSearchPath("res/image")
    cc.FileUtils:getInstance():addSearchPath("res/image/ui")
    cc.FileUtils:getInstance():addSearchPath("res/image/ui/home")
    
    --Initialize the whole run envirement
    local Initialization = require("boot.Initialization")
    Initialization:start()
    
    --first scene 
    --local scene = require("scene.home.HomeScene"):create()
    local scene = require("boot.UpdateScene"):create()

    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(scene)
    else
        cc.Director:getInstance():runWithScene(scene)
    end
end


local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
