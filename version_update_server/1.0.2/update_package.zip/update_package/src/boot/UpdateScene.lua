require "Cocos2d"
require "lfs"
require ("json")

local NEED_UPDATE = true
local server = "http://127.0.0.1/version/versionList.php"

--currVersion 1.1.1, 1.1 is bigVersion, 1 is smallVersion
--key:"current-version-code" is defined in AssetManager in cpp
local currVersion = cc.UserDefault:getInstance():getStringForKey("current-version-code")
local bigVersion = "1.0"

local UpdateScene = class("UpdateScene", function()
    return cc.Scene:create()
end)

function UpdateScene:create()
    local scene = UpdateScene.new()
    scene:initM()
    return scene
end

function UpdateScene:ctor()
end

function UpdateScene:onEnter()
    self:getNewestVersion()
end

function UpdateScene:onExit()
    self.assetsManager:release()
    self.assetsManager = nil
end

function UpdateScene:initM()
    local function onNodeEvent(event)
        if event == "enter" then self:onEnter()
        elseif event == "exit" then self:onExit() end
    end
    self:registerScriptHandler(onNodeEvent)
    
    self.path = cc.FileUtils:getInstance():getWritablePath()
    cclog("[UpdateScene]WritablePath:"..self.path)
    self:createDownPath(self.path)
    self:createDownPath(self.path.."src/")
    self:createDownPath(self.path.."res")
    
    if string.len(currVersion) == 0 then
        currVersion = bigVersion..".0"
    end
    local strs = string.split(currVersion, ".")
    self.currVersion = currVersion
    self.smallVersion = tonumber(strs[3])
    self.bigVersion = strs[1].."."..strs[2]
    
    --big version upate
    if self.bigversion ~= bigVersion then
        --self:delAllFilesInDirectory(self.path)
    end
end

function UpdateScene:createDownPath(path)
    if not self:checkDirOK(path) then
        print("update or create dictionary failed, start game")
        self:noUpdateStart()
        return
    else
        print("update or create dictionary succefully")
    end
end

function UpdateScene:checkDirOK(path)
 
    local oldpath = lfs.currentdir()
    if lfs.chdir(path) then
        lfs.chdir(oldpath)
        return true
    end
    if lfs.mkdir(path) then
        return true
    end
end

function UpdateScene:delAllFilesInDirectory(path)
    for file in lfs.dir(path) do
      if file ~= "." and file ~= ".." then
          local f = path..'/'..file
          local attr = lfs.attributes (f)
          assert (type(attr) == "table")
          if attr.mode == "directory" then
              self:delAllFilesInDirectory (f)
          else
              os.remove(f)
          end
      end
    end
end

local function onError(errorCode)
end

local function onProgress(percent)
end

local function onSuccess()
end

function UpdateScene:downIndexedVersion()
    self.nowDownIndex = self.nowDownIndex or 1
    local versionUrl = self.needDownVersionList[self.nowDownIndex].versionUrl
    local packageUrl = self.needDownVersionList[self.nowDownIndex].packageUrl
    if self.nowDownIndex == 1 then
        self.assetsManager = cc.AssetsManager:new(packageUrl, versionUrl, self.path) --资源包路径，版本号路径，存储路径
        self.assetsManager:retain()
        self.assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
        self.assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
        self.assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS )
        self.assetsManager:setConnectionTimeout(10)
    else
        self.assetsManager:setVersionFileUrl(versionUrl)
        self.assetsManager:setPackageUrl(packageUrl)
    end
    
    if self.assetsManager:checkUpdate() then
        self.assetsManager:update()
    end
end

function UpdateScene:getNewestVersion()
    if not NEED_UPDATE then
        cclog("[UpdateScene]current is debug version, no need for updating")
        --self:noUpdateStart()
        return
    end
    
    local http = cc.XMLHttpRequest:new()
    
    local function httpCallback()
        local result = {}
        local responseStr = http.response
        cclog("--[Http_Recv]--"..responseStr)
        if responseStr == nil or responseStr == "" then
            result.err = 1
            return
        end
        
        local needDownVersions = json.decode(responseStr)
        if needDownVersions.code == 200 then
            self.needDownVersionList = needDownVersions.list
            for i,v in ipairs(self.needDownVersionList) do
                if v.needRestart > 0 then
                    self.needRestart = true
                end
            end
            
            if #self.needDownVersionList > 0 then
                self:downIndexedVersion()
            end
        else
            --self:noUpdateStart()
        end
    end

    http.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    local url = server.."?clientVersion="..self.currVersion
    cclog("[UpdateScene]getNewestVersion url:"..url)
    http:open("GET", url)
    http:registerScriptHandler(httpCallback)
    http:send()
end

function UpdateScene:downHandler(event)
    if event == "success" then
        if self.nowDownIndex < #self.needDownVersionList then
            self.nowDownIndex = self.nowDownIndex + 1
            self:downIndexedVersion()
        else
            cclog("[UpdateScene]update succes")
            --self:afterUpdateStart()
        end
    elseif string.startWith(event, "error") then
    else
    end
end

return UpdateScene
