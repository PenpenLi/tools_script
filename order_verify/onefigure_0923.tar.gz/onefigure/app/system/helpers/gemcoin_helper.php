<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function ValidateGemcoinSignature($email, $transaction_no) {
    $service_code = 'DHBshop01';
    $shop_key = 'DHBshop0120140901';

    $url = "https://api.gemcoin.co.id/receipt.php";
    $post = array(
            'svcCd' => $service_code,
            'email' => $email,
            'shopTrNo' => $transaction_no,
            'key' => md5($shop_key . $email . $service_code),
        );

    $tuCurl = curl_init();
    curl_setopt($tuCurl, CURLOPT_URL, $url);
    curl_setopt($tuCurl, CURLOPT_PORT , 443);
    curl_setopt($tuCurl, CURLOPT_VERBOSE, 0);
    curl_setopt($tuCurl, CURLOPT_HEADER, 0);
    curl_setopt($tuCurl, CURLOPT_SSLVERSION, 3);
    curl_setopt($tuCurl, CURLOPT_POST, 1);
    curl_setopt($tuCurl, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($tuCurl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($tuCurl, CURLOPT_POSTFIELDS, $post);

    $tuData = curl_exec($tuCurl);
    if(!curl_errno($tuCurl)){
      $info = curl_getinfo($tuCurl);
    } else {
      die('Curl error: ' . curl_error($tuCurl));
    }

    curl_close($tuCurl);
    return json_decode($tuData, true);
}