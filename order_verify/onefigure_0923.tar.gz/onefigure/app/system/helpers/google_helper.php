<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function ValidateGooglePlaySignature($receipt, $signature) {
    $receipt = trim($receipt);
    $signature = trim($signature);

    //Create an RSA key compatible with openssl_verify from our Google Play sig
    $key = "-----BEGIN PUBLIC KEY-----\n".
    chunk_split(GOOGLE_PUBLIC_KEY, 64, "\n").
    '-----END PUBLIC KEY-----';
    $key = openssl_pkey_get_public($key);

    if($key == false){
        return $ret = 100;
    }

    //Signature should be in binary format, but it comes as BASE64.
    $signature = base64_decode($signature);

    //Verify the signature
    $result = openssl_verify($receipt, $signature, $key, OPENSSL_ALGO_SHA1);

    if ($result == 1) {
        $ret = 1;
    } elseif ($result == 0) {
        $ret = 0;
    } else {
        $ret = 2;
    }

    return $ret;
}
