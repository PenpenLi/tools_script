<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function PaymentDataToKakao($data = array()) {
    $_array = array();
    foreach ($data as $key => $value) {
        $_array[] = $key . '=' . $value;
    }
    $params_data = implode('&', $_array);

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, KAKAO_PAYMENT_URL);
    curl_setopt($curl, CURLOPT_PORT , 443);
    curl_setopt($curl, CURLOPT_VERBOSE, 0);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSLVERSION, 3);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $params_data);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded", "Content-length: " . strlen($params_data)));
    $curl_data = curl_exec($curl);

    return $curl_data;
}
