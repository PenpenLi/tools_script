<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function curl_get_data($url, $data = '', $data_type = 'text') {
    $headers = array(
            'Content-Type:application/json'
        );

    if ($data_type == 'json') {
        $post_data = json_encode($data);
    } else {
        $post_data = $data;
    }

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
    $curl_data = curl_exec($curl);
    curl_close($curl);

    if ($data_type == 'json') {
        $return_data = json_decode($curl_data, true);
    } else {
        $return_data = $curl_data;
    }

    return $return_data;
}
