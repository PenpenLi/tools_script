<?
echo "ofdpimg.mobirix.net";
?>
