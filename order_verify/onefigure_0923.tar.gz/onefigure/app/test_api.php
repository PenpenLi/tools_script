<?php

function calc_md5($array)
{
    if (!is_array($array))
    {
        return "";
    }

    ksort($array);

    $preSignStr = "";

    foreach ($array as $key => $value) 
    {
        if ($key != "sign")
        {
            if ($preSignStr != "")
            {
                $preSignStr = $preSignStr . "&";
            }
            $preSignStr = $preSignStr . $key . "=" . $value;
        }
    }

    $preSignStr = $preSignStr . "&private_key=sky_game_miyi";

    return md5($preSignStr);
}

function http_post_data($url, $data_string) 
{
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json; charset=utf-8',
			'Content-Length: ' . strlen($data_string))
		);
        ob_start();
        curl_exec($ch);
        $return_content = ob_get_contents();
        ob_end_clean();

        $return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        return array($return_code, $return_content);
}


$url  = "http://gamepms.sky-mobi.com/getOrderId.php";
$msg = array('client_id'=>"fdfefd1f", 'game_name'=>'one_figure1', 'sdk_pay_type'=>'weixi1n' ,'time_stamp'=>date('Y-m-d H:i:s'));
$md5Str = calc_md5($msg);
$msg['sign'] = $md5Str;

$data = json_encode($msg);

list($return_code, $return_content) = http_post_data($url, $data);

print_r($return_content);

?>