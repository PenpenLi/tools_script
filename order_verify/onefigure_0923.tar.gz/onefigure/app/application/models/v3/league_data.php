<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class League_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }
    
    public function selectUserLeague($data = array()) {
        $fields = array(
                'LEAGUE_DATE',
                'GRADE',
                'GROUP_ID',
                'SCORE',
                'REWARD_OK',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'LEAGUE_DATE' => LEAGUE_DATE,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('leagues_ranking')
            ->where($wheres)
            ->get();
        $return = $result->row_array();
        
        return $return;
    }
    
    public function selectUserLeagueLastWeek($data = array()) {
        $fields = array(
                'LEAGUE_DATE',
                'GRADE',
                'GROUP_ID',
                'SCORE',
                'REWARD_OK',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'LEAGUE_DATE' => LEAGUE_LAST_DATE,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('leagues_ranking')
            ->where($wheres)
            ->get();
        $return = $result->row_array();
        
        return $return;
    }
    
    public function insertUserLeague($data = array()) {
        $fields = array(
                'USER_ID',
                'LEAGUE_DATE',
                'GRADE',
                'GROUP_ID',
                'SCORE',
                'REWARD_OK',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('leagues_ranking')
            ->where($wheres)
            ->order_by('LEAGUE_DATE', 'DESC')
            ->get();
        $userRankingRow = $result->row_array();
        
        if (empty($userRankingRow['USER_ID'])) { // 랭킹 없음
            $grade = 10;
        } else if ($userRankingRow['LEAGUE_DATE'] != LEAGUE_LAST_DATE) { // 지난주 랭킹 없음
            $grade = $userRankingRow['GRADE'] + 2;
        } else { // 지난주 랭킹 있음
            $fields = array(
                    'COUNT(*) + 1 AS RANK',
                );
            $wheres = array(
                    'LEAGUE_DATE' => LEAGUE_LAST_DATE,
                    'GRADE' => $userRankingRow['GRADE'],
                    'GROUP_ID' => $userRankingRow['GROUP_ID'],
                    'SCORE > ' => $userRankingRow['SCORE'],
                );
    
            $result = $this->db
                ->select(implode(', ', $fields))
                ->from('leagues_ranking')
                ->where($wheres)
                ->get();
            $rankingRow = $result->row_array();
            $rank = $rankingRow['RANK'];
            
            $grade = $userRankingRow['GRADE'];
            if ($rank < 46) $grade = $grade - 1;
            else if ($rank > 55) $grade = $grade + 1;
        }
        
        if ($grade < 1) $grade = 1;
        else if ($grade > 10) $grade = 10;
        
        $fields = array(
                'GROUP_ID',
                'COUNT(*) AS USER_COUNT',
            );
        $wheres = array(
                'LEAGUE_DATE' => LEAGUE_DATE,
                'GRADE' => $grade,
                'USER_ID > ' => 0,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('leagues_ranking')
            ->where($wheres)
            ->group_by(array('GROUP_ID'))
            ->order_by('GROUP_ID', 'DESC')
            ->get();
        $userCountRow = $result->row_array();
        
        if (empty($userCountRow['GROUP_ID'])) {
            $group_id = 1;
        } else {
            if ($userCountRow['USER_COUNT'] >= 100) {
                $group_id = $userCountRow['GROUP_ID'] + 1;
            } else {
                $group_id = $userCountRow['GROUP_ID'];
            }
        }
        
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'LEAGUE_DATE' => LEAGUE_DATE,
                'GRADE' => $grade,
                'GROUP_ID' => $group_id,
                'SCORE' => 0,
                'REWARD_OK' => 0,
            );

        $this->db->insert('leagues_ranking', $insert);
    }
    
    public function selectLeagueRanking($data = array()) {
        $fields = array(
                'LEAGUE_DATE',
                'GRADE',
                'GROUP_ID',
                'SCORE',
                'REWARD_OK',
            );
        $wheres = array(
                'LEAGUE_DATE' => LEAGUE_DATE,
                'GRADE' => $data['GRADE'],
                'GROUP_ID' => $data['GROUP_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('leagues_ranking')
            ->where($wheres)
            ->order_by('SCORE', 'DESC')
            ->limit(100)
            ->get();
        $return = $result->result_array();
        
        return $return;
    }
    
    public function updateUserLeagueRanking($data = array()) {
        $update = array();
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'LEAGUE_DATE' => LEAGUE_DATE,
            );

        if (!empty($data['SCORE'])) {
            $update['SCORE'] = $data['SCORE'];
            $wheres['SCORE < '] = $data['SCORE'];
        }

        $this->db
            ->where($wheres)
            ->update('leagues_ranking', $update);
    }
    
    public function updateUserLeagueLastWeekRanking($data = array()) {
        $update = array();
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'LEAGUE_DATE' => LEAGUE_LAST_DATE,
            );

        if (!empty($data['REWARD_OK'])) {
            $update['REWARD_OK'] = 1;
        }
        
        $this->db
            ->where($wheres)
            ->update('leagues_ranking', $update);
    }
}