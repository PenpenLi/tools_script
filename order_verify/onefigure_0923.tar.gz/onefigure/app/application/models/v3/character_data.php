<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Character_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectCharacterInfo($data = array()) {
        $fields = array(
                'ITEM_INFO_ID AS CHARACTER_INFO_ID',
                'NAME',
                'BUY',
                'SELL',
                'UPGRADE'
            );
        $wheres = array(
                'ITEM_TYPE' => 1
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['BUY'] = !empty($row['BUY']) ? json_decode($row['BUY'], true) : $row['BUY'];
            $row['SELL'] = !empty($row['SELL']) ? json_decode($row['SELL'], true) : $row['SELL'];
            $row['UPGRADE'] = !empty($row['UPGRADE']) ? json_decode($row['UPGRADE'], true) : $row['UPGRADE'];

            $return[$row['CHARACTER_INFO_ID']] = $row;
        }

        return $return;
    }

    public function selectUserCharacters($data = array(), $return_type = 'json') {
        $fields = array(
                'CHARACTER_ID',
                'CHARACTER_INFO_ID',
                'LEVEL',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
            );
            
        if (!empty($data['CHARACTER_ID'])) {
            $wheres['CHARACTER_ID'] = $data['CHARACTER_ID'];
        }
            
        if (!empty($data['CHARACTER_INFO_ID'])) {
            $wheres['CHARACTER_INFO_ID'] = $data['CHARACTER_INFO_ID'];
        }
            
        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_characters')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($row['CHARACTER_ID'] == $this->_user['CHARACTER_ID']) {
                $slot = 1;
            } else {
                $slot = null;
            }
            
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['CHARACTER_ID'],
                        'itemOriginalID' => $row['CHARACTER_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $slot
                    );
            } else {
                $row['SLOT_NUMBER'] = $slot;
                
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectSlotCharacter($data = array(), $return_type = 'json') {
        $fields = array(
                'CHARACTER_ID',
                'CHARACTER_INFO_ID',
                'LEVEL',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'CHARACTER_ID' => $this->_user['CHARACTER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_characters')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['CHARACTER_ID'],
                        'itemOriginalID' => $row['CHARACTER_INFO_ID'],
                        'level' => $row['LEVEL'],
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function insertUserCharacter($data = array()) {
        $insert = array(
                'CHARACTER_INFO_ID' => $data['CHARACTER_INFO_ID'],
                'USER_ID' => $data['USER_ID'],
                'LEVEL' => 1,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        $this->db->insert('users_characters', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }
    
    public function updateUserCharacter($data = array()) {
        $wheres = array(
                'CHARACTER_ID' => $data['CHARACTER_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('LEVEL', 'LEVEL + 1', false)
            ->update('users_characters');
    }
}