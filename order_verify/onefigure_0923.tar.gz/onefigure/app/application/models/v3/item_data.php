<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Item_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }
    
    public function selectUserInstantItems($data = array(), $return_type = 'json') {
        $fields = array(
                'USER_ID',
                'INSTANT_ITEM_ID',
                'AMOUNT',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
            );
            
        if (!empty($data['INSTANT_ITEM_ID'])) {
            $wheres['INSTANT_ITEM_ID'] = $data['INSTANT_ITEM_ID'];
        }
            
        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_instant_items')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                if ($row['INSTANT_ITEM_ID'] == 0) {
                    $return[] = array(
                            'instantItemID' => $row['INSTANT_ITEM_ID'],
                            'randomItemID' => $row['AMOUNT']
                        );
                } else {
                    $return[] = array(
                            'instantItemID' => $row['INSTANT_ITEM_ID'],
                            'amount' => $row['AMOUNT']
                        );
                }
            } else {
                $return[$row['INSTANT_ITEM_ID']] = $row;
            }
        }

        return $return;
    }
    
    public function insertUserInstantItem($data = array()) {
        $insert = array(
                'INSTANT_ITEM_ID' => $data['INSTANT_ITEM_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        if ($data['INSTANT_ITEM_ID'] == 0) {
            $insert['AMOUNT'] = $data['AMOUNT'];
        } else {
            $insert['AMOUNT'] = 1;
        }
        
        $this->db->insert('users_instant_items', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }
    
    public function updateUserInstantItem($data = array()) {
        $wheres = array(
                'INSTANT_ITEM_ID' => $data['INSTANT_ITEM_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        if ($data['INSTANT_ITEM_ID'] == 0) {
            $this->db->set('AMOUNT', $data['AMOUNT']);
        } else {
            $this->db->set('AMOUNT', 'AMOUNT + 1', false);
        }
        
        return $this->db
            ->where($wheres)
            ->update('users_instant_items');
    }
    
    public function updateUserInstantItemUsed($data = array()) {
        $wheres = array(
                'INSTANT_ITEM_ID' => $data['INSTANT_ITEM_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        if ($data['INSTANT_ITEM_ID'] == 0) {
            $this->db->set('AMOUNT', 0);
        } else {
            $this->db->set('AMOUNT', 'AMOUNT - 1', false);
        }
        
        return $this->db
            ->where($wheres)
            ->update('users_instant_items');
    }
}