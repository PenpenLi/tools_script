<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Treasure_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectTreasureInfo($data = array()) {
        $fields = array(
                'ITEM_INFO_ID AS TREASURE_INFO_ID',
                'NAME',
                'GRADE',
                'BUY',
                'SELL',
                'UPGRADE'
            );
        $wheres = array(
                'ITEM_TYPE' => 3
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['BUY'] = !empty($row['BUY']) ? json_decode($row['BUY'], true) : $row['BUY'];
            $row['SELL'] = !empty($row['SELL']) ? json_decode($row['SELL'], true) : $row['SELL'];
            $row['UPGRADE'] = !empty($row['UPGRADE']) ? json_decode($row['UPGRADE'], true) : $row['UPGRADE'];

            $return[$row['TREASURE_INFO_ID']] = $row;
        }

        return $return;
    }

    public function selectUserTreasures($data = array(), $return_type = 'json') {
        $fields = array(
                'TREASURE_ID',
                'TREASURE_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'IS_DELETE' => 0
            );
            
        if (!empty($data['TREASURE_ID'])) {
            $wheres['TREASURE_ID'] = $data['TREASURE_ID'];
        }
            
        if (!empty($data['TREASURE_INFO_ID'])) {
            $wheres['TREASURE_INFO_ID'] = $data['TREASURE_INFO_ID'];
        }
            
        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_treasures')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['TREASURE_ID'],
                        'itemOriginalID' => $row['TREASURE_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectSlotTreasures($data = array(), $return_type = 'json') {
        $fields = array(
                'TREASURE_ID',
                'TREASURE_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'IS_DELETE' => 0
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_treasures')
            ->where($wheres)
            ->where_in('SLOT_NUMBER', array(1, 2, 3))
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['TREASURE_ID'],
                        'itemOriginalID' => $row['TREASURE_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectRandomTreasures($data = array()) {
        $fields = array(
                'ITEM_INFO_ID AS TREASURE_INFO_ID',
                'NAME',
                'GRADE',
            );
        $wheres = array(
                'ITEM_TYPE' => 3
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->where('ITEM_INFO_ID NOT IN (SELECT TREASURE_INFO_ID FROM op_users_treasures WHERE USER_ID=' . $this->db->escape($data['USER_ID']) . ' AND LEVEL=' . MAX_TREASURE_LEVEL . ' AND IS_DELETE=0)', null, false)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $return[$row['GRADE']][] = $row;
        }

        return $return;
    }

    public function insertUserTreasure($data = array()) {
        $insert = array(
                'TREASURE_INFO_ID' => $data['TREASURE_INFO_ID'],
                'USER_ID' => $data['USER_ID'],
                'LEVEL' => 1,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'IS_DELETE' => 0,
            );

        $this->db->insert('users_treasures', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }
    
    public function updateUserTreasure($data = array()) {
        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('LEVEL', 'LEVEL + 1', false)
            ->update('users_treasures');
    }
    
    public function updateUserTreasureSlot($data = array()) {
        $this->db
            ->where('USER_ID', $data['USER_ID'])
            ->where('SLOT_NUMBER', $data['SLOT_NUMBER'])
            ->set('SLOT_NUMBER', null)
            ->update('users_treasures');
            
        $update = array(
                'SLOT_NUMBER' => $data['SLOT_NUMBER'],
            );

        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->update('users_treasures', $update);
    }
    
    public function deleteUserTreasure($data = array()) {
        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('IS_DELETE', 1)
            ->set('DELETE_DATE', date('Y-m-d H:i:s'))
            ->update('users_treasures');
    }
    
}