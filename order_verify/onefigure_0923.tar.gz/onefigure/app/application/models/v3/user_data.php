<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class User_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectUser($data = array()) {
        $fields = array(
                'USER_ID',
                'EMAIL',
                'PASSWORD',
                'NICKNAME',
                'LEVEL',
                'EXP_POINT',
                'MONEY',
                'CASH',
                'HEART',
                'HEART_TIME',
                'LOTTERY_POINT',
                'LOTTERY_COUPON',
                'CHARACTER_ID',
                'SKILL_SLOT',
                'TREASURE_SLOT',
                'TREASURE_INVENTORY',
                'BEST_SCORE',
                'INVITE_COUNT',
                'AGREE_MESSAGE',
                'TUTORIAL',
                'REVIEW',
                'OS_TYPE',
                'MARKET_TYPE',
                'LOGIN_DATE',
            );
        $wheres = array(
                'STATUS' => 1
            );

        if (!empty($data['USER_ID'])) {
            $wheres['USER_ID'] = $data['USER_ID'];
        }

        if (!empty($data['EMAIL'])) {
            $wheres['EMAIL'] = $data['EMAIL'];
        }

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function selectUserNicknameCount($data = array()) {
        $wheres = array(
                'STATUS' => 1,
                'USER_ID !=' => $data['USER_ID'],
                'NICKNAME' => $data['NICKNAME']
            );

        return $this->db
            ->from('users')
            ->where($wheres)
            ->count_all_results();
    }

    public function updateUser($data = array()) {
        $update = array();
        $wheres = array(
                'USER_ID' => $data['USER_ID']
            );

        if (isset($data['NICKNAME'])) {
            $update['NICKNAME'] = $data['NICKNAME'];
        }

        if (isset($data['PASSWORD'])) {
            $update['PASSWORD'] = md5($data['PASSWORD']);
        }

        if (isset($data['LEVEL'])) {
            $update['LEVEL'] = $data['LEVEL'];
        }

        if (isset($data['EXP_POINT'])) {
            $update['EXP_POINT'] = $data['EXP_POINT'];
        }

        if (isset($data['STATUS']) && is_numeric($data['STATUS'])) {
            $update['STATUS'] = $data['STATUS'];

            if ($data['STATUS'] == 0) {
                $update['DELETE_DATE'] = date('Y-m-d H:i:s');
                $update['DELETE_IP'] = $this->input->ip_address();
            }
        }

        if (isset($data['CHARACTER_ID'])) {
            $update['CHARACTER_ID'] = $data['CHARACTER_ID'];
        }

        if (isset($data['SKILL_SLOT'])) {
            if ($data['SKILL_SLOT'] > MAX_SKILL_SLOT) {
                $data['SKILL_SLOT'] = MAX_SKILL_SLOT;
            }

            $update['SKILL_SLOT'] = $data['SKILL_SLOT'];
        }

        if (isset($data['TREASURE_SLOT'])) {
            if ($data['TREASURE_SLOT'] > MAX_TREASURE_SLOT) {
                $data['TREASURE_SLOT'] = MAX_TREASURE_SLOT;
            }

            $update['TREASURE_SLOT'] = $data['TREASURE_SLOT'];
        }

        if (isset($data['TREASURE_INVENTORY'])) {
            if ($data['TREASURE_INVENTORY'] > MAX_TREASURE_INVENTORY) {
                $data['TREASURE_INVENTORY'] = MAX_TREASURE_INVENTORY;
            }

            $update['TREASURE_INVENTORY'] = $data['TREASURE_INVENTORY'];
        }

        if (isset($data['SCORE'])) {
            $this->db->set('BEST_SCORE', 'IF(BEST_SCORE < ' . $data['SCORE'] . ', ' . $data['SCORE'] . ', BEST_SCORE)', false);
        }

        if (isset($data['INVITE_COUNT'])) {
            $update['INVITE_COUNT'] = $data['INVITE_COUNT'];
        }

        if (isset($data['REVIEW'])) {
            $update['REVIEW'] = $data['REVIEW'];
        }

        if (isset($data['DEVICE'])) {
            $update['DEVICE'] = $data['DEVICE'];
        }

        if (isset($data['OS_TYPE'])) {
            $update['OS_TYPE'] = $data['OS_TYPE'];
        }

        if (isset($data['OS_VERSION'])) {
            $update['OS_VERSION'] = $data['OS_VERSION'];
        }

        if (isset($data['MARKET_TYPE'])) {
            $update['MARKET_TYPE'] = $data['MARKET_TYPE'];
        }

        if (isset($data['PUSH_ID'])) {
            $update['PUSH_ID'] = $data['PUSH_ID'];
        }

        if (isset($data['TUTORIAL'])) {
            $update['TUTORIAL'] = $data['TUTORIAL'];
        }

        if (isset($data['AGREE_MESSAGE'])) {
            $update['AGREE_MESSAGE'] = $data['AGREE_MESSAGE'];
        }

        if (isset($data['CELLPHONE'])) {
            $update['CELLPHONE'] = $data['CELLPHONE'];
        }

        if (isset($data['IS_UPDATE'])) {
            $update['UPDATE_DATE'] = date('Y-m-d H:i:s');
            $update['UPDATE_IP'] = $this->input->ip_address();
        }

        if (isset($data['IS_LOGIN'])) {
            $update['LOGIN_DATE'] = date('Y-m-d H:i:s');
            $update['LOGIN_IP'] = $this->input->ip_address();
        }

        $this->db
            ->where($wheres)
            ->update('users', $update);
    }

    public function insertUser($data = array()) {
        $insert = array(
                'EMAIL' => $data['EMAIL'],
                'PASSWORD' => md5($data['PASSWORD']),
                'NICKNAME' => '',
                'LEVEL' => DEFAULT_USER_LEVEL,
                'EXP_POINT' => DEFAULT_USER_EXP_POINT,
                'HEART' => DEFAULT_USER_HEART,
                'HEART_TIME' => null,
                'TREASURE_INVENTORY' => DEFAULT_USER_TREASURE_INVENTORY,
                'STATUS' => 1,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'CREATE_IP' => $this->input->ip_address(),
            );

        $this->db->insert('users', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }

    public function selectBanner($data = array()) {
        $fields = array(
                'BANNER_ID',
                'NAME',
                'IMAGE_URL',
                'LINK_URL',
                'CALLBACK_URL',
                'START_DATE',
                'END_DATE',
                'REWARD_ACTION',
                'EVENT_ID',
                'IS_DELETE',
            );
        $wheres = array(
                'BANNER_ID' => $data['BANNER_ID'],
                'IS_DELETE' => 0,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('banners')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $return = $row;
            $return['IMAGE_URL_JSON'] = $row['IMAGE_URL'];
            $return['IMAGE_URL'] = json_decode($row['IMAGE_URL'], true);
            $return['LINK_URL_JSON'] = $row['LINK_URL'];
            $return['LINK_URL'] = json_decode($row['LINK_URL'], true);
            $return['CALLBACK_URL_JSON'] = $row['CALLBACK_URL'];
            $return['CALLBACK_URL'] = json_decode($row['CALLBACK_URL'], true);
        }

        return $return;
    }

    public function selectBannerRandom($data = array()) {
        $fields = array(
                'BANNER_ID',
                'NAME',
                'IMAGE_URL',
                'LINK_URL',
                'CALLBACK_URL',
                'START_DATE',
                'END_DATE',
                'REWARD_ACTION',
                'EVENT_ID',
                'IS_DELETE',
            );
        $wheres = array(
                'IS_DELETE' => 0,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('banners')
            ->where($wheres)
            ->where('NOW() BETWEEN START_DATE AND END_DATE')
            ->where('BANNER_ID NOT IN (SELECT BANNER_ID FROM op_banners_users WHERE USER_ID=' . $data['USER_ID'] . ')')
            ->limit(1)
            ->order_by('BANNER_ID', 'RANDOM')
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $return = $row;
            $return['IMAGE_URL_JSON'] = $row['IMAGE_URL'];
            $return['IMAGE_URL'] = json_decode($row['IMAGE_URL'], true);
            $return['LINK_URL_JSON'] = $row['LINK_URL'];
            $return['LINK_URL'] = json_decode($row['LINK_URL'], true);
            $return['CALLBACK_URL_JSON'] = $row['CALLBACK_URL'];
            $return['CALLBACK_URL'] = json_decode($row['CALLBACK_URL'], true);
        }

        return $return;
    }

    public function selectBannerCallback($data = array()) {
        $fields = array(
                'B.BANNER_ID',
                'B.CALLBACK_URL',
                'B.EVENT_ID',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'B.REWARD_ACTION' => 2,
                'STATUS' => 0,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('banners B')
            ->join('banners_users U', 'B.BANNER_ID=U.BANNER_ID')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['IMAGE_URL_JSON'] = $row['IMAGE_URL'];
            $row['IMAGE_URL'] = json_decode($row['IMAGE_URL'], true);
            $row['LINK_URL_JSON'] = $row['LINK_URL'];
            $row['LINK_URL'] = json_decode($row['LINK_URL'], true);
            $row['CALLBACK_URL_JSON'] = $row['CALLBACK_URL'];
            $row['CALLBACK_URL'] = json_decode($row['CALLBACK_URL'], true);
            $return[] = $row;
        }

        return $return;
    }

    public function getBannerUserData($data = array()) {
        $fields = array(
                'USER_ID',
                'BANNER_ID',
                'STATUS',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'BANNER_ID' => $data['BANNER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('banners_users')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function addBannerUserData($data = array()) {
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'BANNER_ID' => $data['BANNER_ID'],
                'STATUS' => $data['STATUS'],
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        $this->db->insert('banners_users', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }

    public function setBannerUserData($data = array()) {
        $update = array(
                'STATUS' => 1,
                'REWARD_DATE' => date('Y-m-d H:i:s'),
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'BANNER_ID' => $data['BANNER_ID'],
            );

        $this->db
            ->where($wheres)
            ->update('banners_users', $update);
    }
}
