<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Skill_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectSkillInfo($data = array()) {
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));

        if (!$return = $this->cache->get('ofdp-skill')) {
            $this->load->library(array('Docs_reader', 'Curl'));
            $this->load->helper(array('file'));
            $this->config->load('docs');
            $docs = $this->config->item('docs');

            $this->curl->create($docs['url']['item']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $itemRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $this->curl->create($docs['url']['price']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $priceRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $this->curl->create($docs['url']['enchant']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $enchantRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $enchant = array();
            foreach ($enchantRows as $index => $row) {
                $level = $index + 2;
                $enchant['A'][$level] = array('RATE' => $row['rateA'], 'CASH' => $row['cashA']);
                $enchant['B'][$level] = array('RATE' => $row['rateB'], 'CASH' => $row['cashB']);
                $enchant['C'][$level] = array('RATE' => $row['rateC'], 'CASH' => $row['cashC']);
            }

            $return = array();
            foreach ($itemRows as $row) {
                if ($row['index'] < 100 || $row['index'] >= 1000) continue;

                $buy = array();
                foreach ($priceRows as $r) {
                    if ($r['type'] == 'MystiqueSlot' || $r['type'] == 'ArtifactSlot') continue;

                    if ($r['index'] == $row['index']) {
                        if ($r['limitType'] == 'Level') {
                            $buy['LEVEL'] = $r['limitValue'];
                        }

                        if ($r['limitBuyType'] == 'Cash') {
                            $buy['CASH'] = $r['limitBuyValue'];
                        }

                        if ($r['buyType'] == 'Money') {
                            $buy['MONEY'] = $r['buyValue'];
                        }
                    }
                }

                $upgrade = $enchant[$row['grade']];
                for ($i = 1; $i <= MAX_SKILL_LEVEL; $i++) {
                    $upgrade[$i]['FACTOR'] = $row['enchantFactor'];
                    $upgrade[$i]['MONEY'] = $row['enchantPrice'];
                }

                $return[$row['index']] = array(
                    'SKILL_INFO_ID' => $row['index'],
                    'NAME' => $row['name'],
                    'GRADE' => $row['grade'],
                    'BUY' => $buy,
                    'UPGRADE' => $upgrade,
                );
            }

            $this->cache->save('ofdp-skill', $return, CACHE_REFRESH_TIME);
        }

        return $return;
    }

    public function _selectSkillInfo($data = array()) {
        $fields = array(
                'ITEM_INFO_ID AS SKILL_INFO_ID',
                'NAME',
                'BUY',
                'SELL',
                'UPGRADE'
            );
        $wheres = array(
                'ITEM_TYPE' => 2
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['BUY'] = !empty($row['BUY']) ? json_decode($row['BUY'], true) : $row['BUY'];
            $row['SELL'] = !empty($row['SELL']) ? json_decode($row['SELL'], true) : $row['SELL'];
            $row['UPGRADE'] = !empty($row['UPGRADE']) ? json_decode($row['UPGRADE'], true) : $row['UPGRADE'];

            $return[$row['SKILL_INFO_ID']] = $row;
        }

        return $return;
    }

    public function selectUserSkills($data = array(), $return_type = 'json') {
        $fields = array(
                'SKILL_ID',
                'SKILL_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
            );
            
        if (!empty($data['SKILL_ID'])) {
            $wheres['SKILL_ID'] = $data['SKILL_ID'];
        }
            
        if (!empty($data['SKILL_INFO_ID'])) {
            $wheres['SKILL_INFO_ID'] = $data['SKILL_INFO_ID'];
        }
            
        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_skills')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['SKILL_ID'],
                        'itemOriginalID' => $row['SKILL_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectSlotSkills($data = array(), $return_type = 'json') {
        $fields = array(
                'SKILL_ID',
                'SKILL_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_skills')
            ->where($wheres)
            ->where_in('SLOT_NUMBER', array(1, 2, 3))
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['SKILL_ID'],
                        'itemOriginalID' => $row['SKILL_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function insertUserSkill($data = array()) {
        $insert = array(
                'SKILL_INFO_ID' => $data['SKILL_INFO_ID'],
                'USER_ID' => $data['USER_ID'],
                'LEVEL' => 1,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        $this->db->insert('users_skills', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }
    
    public function updateUserSkill($data = array()) {
        $wheres = array(
                'SKILL_ID' => $data['SKILL_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('LEVEL', 'LEVEL + 1', false)
            ->update('users_skills');
    }
    
    public function updateUserSkillSlot($data = array()) {
        $this->db
            ->where('USER_ID', $data['USER_ID'])
            ->where('SLOT_NUMBER', $data['SLOT_NUMBER'])
            ->set('SLOT_NUMBER', null)
            ->update('users_skills');
            
        $update = array(
                'SLOT_NUMBER' => $data['SLOT_NUMBER'],
            );

        $wheres = array(
                'SKILL_ID' => $data['SKILL_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->update('users_skills', $update);
    }
}