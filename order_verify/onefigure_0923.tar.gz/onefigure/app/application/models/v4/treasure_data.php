<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Treasure_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectTreasureInfo($data = array()) {
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));

        if (!$return = $this->cache->get('ofdp-treasure')) {
            $this->load->library(array('Docs_reader', 'Curl'));
            $this->load->helper(array('file'));
            $this->config->load('docs');
            $docs = $this->config->item('docs');

            $this->curl->create($docs['url']['item']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $itemRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $this->curl->create($docs['url']['price']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $priceRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $this->curl->create($docs['url']['enchant']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $enchantRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');

            $enchant = array();
            foreach ($enchantRows as $index => $row) {
                $level = $index + 2;
                $enchant['A'][$level] = array('RATE' => $row['rateA'], 'CASH' => $row['cashA']);
                $enchant['B'][$level] = array('RATE' => $row['rateB'], 'CASH' => $row['cashB']);
                $enchant['C'][$level] = array('RATE' => $row['rateC'], 'CASH' => $row['cashC']);
            }

            $return = array();
            foreach ($itemRows as $row) {
                if ($row['index'] < 1000) continue;

                $buy = array();
                foreach ($priceRows as $r) {
                    if ($r['type'] == 'MystiqueSlot' || $r['type'] == 'ArtifactSlot') continue;

                    if ($r['index'] == $row['index']) {
                        if ($r['limitType'] == 'Level') {
                            $buy['LEVEL'] = $r['limitValue'];
                        }

                        if ($r['limitBuyType'] == 'Cash') {
                            $buy['CASH'] = $r['limitBuyValue'];
                        }

                        if ($r['buyType'] == 'Money') {
                            $buy['MONEY'] = $r['buyValue'];
                        }
                    }
                }

                $upgrade = $enchant[$row['grade']];
                for ($i = 1; $i <= MAX_TREASURE_LEVEL; $i++) {
                    $upgrade[$i]['FACTOR'] = $row['enchantFactor'];
                    $upgrade[$i]['MONEY'] = $row['enchantPrice'];
                }

                $return[$row['index']] = array(
                    'TREASURE_INFO_ID' => $row['index'],
                    'NAME' => $row['name'],
                    'GRADE' => $row['grade'],
                    'BUY' => $buy,
                    'UPGRADE' => $upgrade,
                );
            }

            $this->cache->save('ofdp-treasure', $return, CACHE_REFRESH_TIME);
        }

        return $return;
    }

    public function _selectTreasureInfo($data = array()) {
        $fields = array(
                'ITEM_INFO_ID AS TREASURE_INFO_ID',
                'NAME',
                'GRADE',
                'BUY',
                'SELL',
                'UPGRADE'
            );
        $wheres = array(
                'ITEM_TYPE' => 3
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['BUY'] = !empty($row['BUY']) ? json_decode($row['BUY'], true) : $row['BUY'];
            $row['SELL'] = !empty($row['SELL']) ? json_decode($row['SELL'], true) : $row['SELL'];
            $row['UPGRADE'] = !empty($row['UPGRADE']) ? json_decode($row['UPGRADE'], true) : $row['UPGRADE'];

            $return[$row['TREASURE_INFO_ID']] = $row;
        }

        return $return;
    }

    public function selectUserTreasures($data = array(), $return_type = 'json') {
        $fields = array(
                'TREASURE_ID',
                'TREASURE_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
                'CREATE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'IS_DELETE' => 0
            );
            
        if (!empty($data['TREASURE_ID'])) {
            $wheres['TREASURE_ID'] = $data['TREASURE_ID'];
        }
            
        if (!empty($data['TREASURE_INFO_ID'])) {
            $wheres['TREASURE_INFO_ID'] = $data['TREASURE_INFO_ID'];
        }
            
        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_treasures')
            ->where($wheres)
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['TREASURE_ID'],
                        'itemOriginalID' => $row['TREASURE_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectSlotTreasures($data = array(), $return_type = 'json') {
        $fields = array(
                'TREASURE_ID',
                'TREASURE_INFO_ID',
                'LEVEL',
                'SLOT_NUMBER',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'IS_DELETE' => 0
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_treasures')
            ->where($wheres)
            ->where_in('SLOT_NUMBER', array(1, 2, 3))
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            if ($return_type == 'json') {
                $return[] = array(
                        'itemID' => $row['TREASURE_ID'],
                        'itemOriginalID' => $row['TREASURE_INFO_ID'],
                        'level' => $row['LEVEL'],
                        'slot' => $row['SLOT_NUMBER']
                    );
            } else {
                $return[] = $row;
            }
        }

        return $return;
    }

    public function selectRandomTreasures($data = array()) {
        $treasureInfoRows = $this->selectTreasureInfo($data);
        $treasureRows = $this->selectUserTreasures($data, 'array');

        foreach ($treasureRows as $row) {
            if ($row['LEVEL'] == MAX_TREASURE_LEVEL) {
                unset($treasureInfoRows[$row['TREASURE_INFO_ID']]);
            }
        }

        $return = array();
        foreach ($treasureInfoRows as $row) {
            $return[$row['GRADE']][] = $row;
        }

        return $return;
    }

    public function insertUserTreasure($data = array()) {
        $insert = array(
                'TREASURE_INFO_ID' => $data['TREASURE_INFO_ID'],
                'USER_ID' => $data['USER_ID'],
                'LEVEL' => 1,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'IS_DELETE' => 0,
            );

        $this->db->insert('users_treasures', $insert);

        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }
    
    public function updateUserTreasure($data = array()) {
        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('LEVEL', 'LEVEL + 1', false)
            ->update('users_treasures');
    }
    
    public function updateUserTreasureSlot($data = array()) {
        $this->db
            ->where('USER_ID', $data['USER_ID'])
            ->where('SLOT_NUMBER', $data['SLOT_NUMBER'])
            ->set('SLOT_NUMBER', null)
            ->update('users_treasures');
            
        $update = array(
                'SLOT_NUMBER' => $data['SLOT_NUMBER'],
            );

        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->update('users_treasures', $update);
    }
    
    public function deleteUserTreasure($data = array()) {
        $wheres = array(
                'TREASURE_ID' => $data['TREASURE_ID'],
                'USER_ID' => $data['USER_ID'],
            );

        return $this->db
            ->where($wheres)
            ->set('IS_DELETE', 1)
            ->set('DELETE_DATE', date('Y-m-d H:i:s'))
            ->update('users_treasures');
    }
    
}