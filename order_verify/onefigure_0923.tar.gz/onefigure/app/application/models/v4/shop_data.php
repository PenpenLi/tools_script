<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Shop_data extends CI_Model {
    public function __construct() {
        parent::__construct();
        //print_r($this);exit();

        $this->load->database();
        $this->load->model(array('Log_data'));
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectItemInfo($data = array()) {
        $fields = array(
                'ITEM_INFO_ID',
                'NAME',
                'PRICE_TYPE',
                'PRICE_AMOUNT',
                'AMOUNT'
            );
        $wheres = array(
                'IS_DELETE' => 0
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('game_item')
            ->where($wheres)
            ->order_by('ITEM_INFO_ID', 'ASC')
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $return[$row['ITEM_INFO_ID']] = $row;
        }

        return $return;
    }

    public function selectInAppPurchaseInfo($data = array()) {
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
        
        if (!$return = $this->cache->get('ofdp-iap')) {
            $this->load->library(array('Docs_reader', 'Curl'));
            $this->load->helper(array('file'));
            $this->config->load('docs');
            $docs = $this->config->item('docs');
            
            $this->curl->create($docs['url']['iap']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $docsRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');
            
            $return = array();
            foreach ($docsRows as $row) {
                if (strtolower($row['productType']) == 'cash') $product_type = 1;
                else $product_type = 2;
                
                $return[$row['productID']] = array(
                        'ITEM_ID' => $row['itemID'],
                        'PRODUCT_TYPE' => $product_type,
                        'PRODUCT_ID' => $row['productID'],
                        'AMOUNT' => $row['amount'],
                        'NAME' => $row['name'],
                        'PRICE_KR' => $row['priceKr'],
                        'PRICE_US' => $row['priceUs'],
                        'MORE_AMOUNT' => 0,
                        'MORE_PERCENT' => 0,
                    );
            }
            
            $this->cache->save('ofdp-iap', $return, CACHE_REFRESH_TIME);
        }

        return $return;
    }

    public function selectGamblingInfo($data = array()) {
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
        
        if (!$return = $this->cache->get('ofdp-gambling')) {
            $this->load->library(array('Docs_reader', 'Curl'));
            $this->load->helper(array('file'));
            $this->config->load('docs');
            $docs = $this->config->item('docs');
            
            $this->curl->create($docs['url']['gambling']);
            $contents = $this->curl->execute();
            write_file('/tmp/ofdp_docs_temp_file', $contents);
            $docsRows = $this->docs_reader->parse_file('/tmp/ofdp_docs_temp_file');
            
            $group_array = array('Reward_Stage' => 1, 'PresentBox' => 2);
            $type_array = array('Money' => 0, 'Cash' => 1, 'Stamina' => 2, 'Mystique' => 3, 'Stance' => 4, 'Artifact' => 5, 'Point' => 6, 'Exp' => 7);
            
            $return = array();
            foreach ($docsRows as $row) {
                $return[$group_array[$row['groupID']]][] = array(
                        'GROUP' => $group_array[$row['groupID']],
                        'TYPE' => $type_array[$row['type']],
                        'ITEM_ID' => $row['itemIndex'],
                        'AMOUNT' => $row['count'],
                        'RATE' => $row['rate'],
                    );
            }
            
            $this->cache->save('ofdp-gambling', $return, CACHE_REFRESH_TIME);
        }

        return $return;
    }

    public function updateUserPoint($point_type, $point, $category, $user_id) {
        $this->load->model('Log_data');
        $bonus_point = 0;
        
        if ($point_type == 1) {
            $point_field = 'MONEY';
            $field_set = $point_field . ' + ' . $point;
            
            if ($point <= -1000) {
                $bonus_point = floor(abs($point) / 1000);
            } else if ($point <= -500) {
                $bonus_point = 3;
            }
            
           $this->datainputoutput->set('money', $this->datainputoutput->get('money') + $point);
        } else if ($point_type == 2) {
            $point_field = 'CASH';
            $field_set = $point_field . ' + ' . $point;
            
            $bonus_point = abs($point);
            
            $this->datainputoutput->set('cash', $this->datainputoutput->get('cash') + $point);
        } else if ($point_type == 3) {
            $point_field = 'LOTTERY_POINT';
            $field_set = 'IF((' . $point_field . ' + ' . $point . ') > ' . MAX_LOTTERY_POINT . ', ' . MAX_LOTTERY_POINT . ', ' . $point_field . ' + ' . $point . ')';
            
            $this->datainputoutput->set('lotteryPoint', $this->datainputoutput->get('lotteryPoint') + $point);
        } else if ($point_type == 4) {
            $point_field = 'LOTTERY_COUPON';
            $field_set = $point_field . ' + ' . $point;
            
            $this->datainputoutput->set('lotteryCoupon', $this->datainputoutput->get('cash') + $point);
        }
        
        $this->db->trans_start();
        $this->db
            ->where('USER_ID', $user_id)
            ->set($point_field, $field_set, false)
            ->update('users');
        $this->Log_data->insertPointLog($point_type, $point, $category, $user_id);
        
        if ($bonus_point > 0) {
            $this->db
                ->where('USER_ID', $user_id)
                ->set('LOTTERY_POINT', 'IF((LOTTERY_POINT + ' . $bonus_point . ') > ' . MAX_LOTTERY_POINT . ', ' . MAX_LOTTERY_POINT . ', LOTTERY_POINT + ' . $bonus_point . ')', false)
                ->update('users');
            $this->Log_data->insertPointLog(3, $bonus_point, $category, $user_id);
            
            $this->datainputoutput->set('lotteryPoint', $this->datainputoutput->get('lotteryPoint') + $bonus_point);
        }
        
        $this->db->trans_complete();
    }

    public function selectUserGameItem($data = array()) {
        $fields = array(
                'USER_ID',
                'ITEM_INFO_ID',
                'AMOUNT',
            );
        $wheres = array(
               'USER_ID' => $data['USER_ID']
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_items')
            ->where($wheres)
            ->get();
        
        $return = array();
        foreach ($result->result_array() as $row) {
            $return[$row['ITEM_INFO_ID']] = $row['AMOUNT'];
        }

        return $return;
    }

    public function updateUserGameItem($data = array()) {
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'ITEM_INFO_ID' => $data['ITEM_INFO_ID'],
            );

        $this->db->trans_start();
        
        $count = $this->db
            ->from('users_items')
            ->where($wheres)
            ->count_all_results();

        if ($count > 0) {
            if (isset($data['IS_AMOUNT']) && $data['IS_AMOUNT'] == true) {
                $this->db->set('AMOUNT', 'AMOUNT + 1', false);
            } else if (isset($data['IS_LEVEL']) && $data['IS_LEVEL'] == true) {
                $this->db->set('LEVEL', 'LEVEL + 1', false);
            }
            
            $this->db
                ->where($wheres)
                ->update('users_items');
        } else {
            $insert = array(
                    'USER_ID' => $data['USER_ID'],
                    'ITEM_INFO_ID' => $data['ITEM_INFO_ID'],
                    'AMOUNT' => 1,
                    'CREATE_DATE' => date('Y-m-d H:i:s'),
                );
                
            if (isset($data['IS_LEVEL']) && $data['IS_LEVEL'] == true) {
                $insert['LEVEL'] = 1;
            }
            
            $this->db->insert('users_items', $insert);
        }
        
        $this->db->trans_complete();
    }

    public function selectMarketOrder($data = array()) {
        $fields = array(
                'USER_ID',
                'PRODUCT_ID',
                'ORDER_ID',
                'PURCHASE_TOKEN',
                'SIGNATURE',
                'CREATE_DATE',
            );
        $wheres = array(
               'ORDER_ID' => $data['ORDER_ID']
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('market_order')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function insertMarketOrder($data = array()) {
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'PRODUCT_ID' => $data['PRODUCT_ID'],
                'ORDER_ID' => $data['ORDER_ID'],
                'PURCHASE_TOKEN' => $data['PURCHASE_TOKEN'],
                'SIGNATURE' => $data['SIGNATURE'],
                'KAKAO_CODE' => $data['KAKAO_CODE'],
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        return $this->db->insert('market_order', $insert);
    }

    public function selectBuy($data = array()) {
        $fields = array(
                'BUY_ID',
                'IS_FINISH',
                'CREATE_DATE',
                'FINISH_DATE',
            );
        $wheres = array(
               'BUY_ID' => $data['BUY_ID'],
               'USER_ID' => $data['USER_ID']
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('buy')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function insertBuy($data = array()) {
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'IS_FINISH' => 0,
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        $this->db->insert('buy', $insert);
        
        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return -1;
        }
    }

    public function updateBuy($data = array()) {
        $wheres = array(
               'BUY_ID' => $data['BUY_ID'],
               'USER_ID' => $data['USER_ID']
            );
        
        $update = array(
                'IS_FINISH' => 1,
                'FINISH_DATE' => date('Y-m-d H:i:s'),
            );

        return $this->db
            ->where($wheres)
            ->update('buy', $update);
    }
}