<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Friend_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectFriends($data = array(), $return_type = 'json') {
        $fields = array(
                'F.USER_ID',
                'F.FRIEND_USER_ID',
                'NICKNAME',
                'U.LEVEL',
                'AGREE_MESSAGE',
                'LOGIN_DATE',
                'C.CHARACTER_ID',
                'C.CHARACTER_INFO_ID',
                'C.LEVEL AS CHARACTER_LEVEL',
                'BEST_SCORE',
                'F.CREATE_DATE',
                'F.DELETE_DATE',
                'F.PLAY_DATE',
                'F.STATUS',
                '(SELECT MAX(CREATE_DATE) FROM op_messages WHERE SEND_USER_ID=F.USER_ID AND RECIEVE_USER_ID=F.FRIEND_USER_ID) AS RECENT_MESSAGE_DATE',
            );
        $wheres = array(
                'F.USER_ID' => $data['USER_ID'],
                'F.STATUS < ' => 3,
                'U.STATUS' => 1,
            );

        if (!empty($data['FRIEND_USER_ID'])) {
            $wheres['F.FRIEND_USER_ID'] = $data['FRIEND_USER_ID'];
        }

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_friends F')
            ->join('users U', 'F.FRIEND_USER_ID=U.USER_ID')
            ->join('users_characters C', 'C.CHARACTER_ID=U.CHARACTER_ID')
            ->join('leagues_ranking_' . LEAGUE_DATE . ' R', 'R.USER_ID=U.USER_ID', 'LEFT OUTER')
            ->where($wheres)
            ->get();

        $friends = array();
        $friends_id = array();
        foreach ($result->result_array() as $row) {
            $friends_id[] = $row['FRIEND_USER_ID'];
            
            $row['SKILLS'] = array();
            $row['TREASURES'] = array();
            $friends[$row['FRIEND_USER_ID']] = $row;
        }
        
        if (count($friends) > 0) {
            $fields = array(
                    'SKILL_ID',
                    'SKILL_INFO_ID',
                    'USER_ID',
                    'LEVEL',
                    'SLOT_NUMBER',
                );
            $wheres = array(
                    'SLOT_NUMBER > ' => 0,
                );
    
            $skills = $this->db
                ->select(implode(', ', $fields))
                ->from('users_skills')
                ->where($wheres)
                ->where_in('USER_ID', $friends_id)
                ->get();
            
            foreach ($skills->result_array() as $row) {
                $friends[$row['USER_ID']]['SKILLS'][] = $row; 
            }
            
            $fields = array(
                    'TREASURE_ID',
                    'TREASURE_INFO_ID',
                    'USER_ID',
                    'LEVEL',
                    'SLOT_NUMBER',
                );
            $wheres = array(
                    'SLOT_NUMBER > ' => 0,
                    'IS_DELETE' => 0,
                );
    
            $treasures = $this->db
                ->select(implode(', ', $fields))
                ->from('users_treasures')
                ->where($wheres)
                ->where_in('USER_ID', $friends_id)
                ->get();
            
            foreach ($treasures->result_array() as $row) {
                $friends[$row['USER_ID']]['TREASURES'][] = $row; 
            }
        }

        $return = array();
        foreach ($friends as $friend_user_id => $row) {
            if ($return_type == 'json') {
                $skill = array();
                foreach ($row['SKILLS'] as $s) {
                    $skill[] = array(
                            'itemID' => $s['SKILL_ID'],
                            'itemOriginalID' => $s['SKILL_INFO_ID'],
                            'level' => $s['LEVEL'],
                            'slot' => $s['SLOT_NUMBER']
                    );
                }
                
                $treasure = array();
                foreach ($row['TREASURES'] as $s) {
                    $treasure[] = array(
                            'itemID' => $s['TREASURE_ID'],
                            'itemOriginalID' => $s['TREASURE_INFO_ID'],
                            'level' => $s['LEVEL'],
                            'slot' => $s['SLOT_NUMBER']
                    );
                }
                
                $return[$row['STATUS']][] = array(
                        'userID' => $row['FRIEND_USER_ID'],
                        'nickname' => $row['NICKNAME'],
                        'level' => $row['LEVEL'],
                        'score' => $row['BEST_SCORE'],
                        'agreeMessage' => $row['AGREE_MESSAGE'],
                        'loginDate' => $row['LOGIN_DATE'],
                        'loginDateTime' => (time() - strtotime($row['LOGIN_DATE'])),
                        'recentMessageDate' => $row['RECENT_MESSAGE_DATE'],
                        'recentMessageDateTime' => (time() - strtotime($row['RECENT_MESSAGE_DATE'])),
                        'playDate' => $row['PLAY_DATE'],
                        'playDateTime' => empty($row['PLAY_DATE']) ? null : (time() - strtotime($row['PLAY_DATE'])),
                        'character' => array(
                                'itemID' => $row['CHARACTER_ID'],
                                'itemOriginalID' => $row['CHARACTER_INFO_ID'],
                                'level' => $row['CHARACTER_LEVEL'],
                            ),
                        'skills' => $skill,
                        'treasures' => $treasure,
                    );
            } else {
                $return[] = $row;
            }
        }
        
        return $return;
    }

    public function selectFriend($data = array()) {
        $fields = array(
                'USER_ID',
                'FRIEND_USER_ID',
                'CREATE_DATE',
                'DELETE_DATE',
                'PLAY_DATE',
                'STATUS',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'FRIEND_USER_ID' => $data['FRIEND_USER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users_friends')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function selectSearchFriends($data = array()) {
        $fields = array(
                'U.USER_ID',
                'U.EMAIL',
                'U.NICKNAME',
                'U.LEVEL',
                'U.AGREE_MESSAGE',
                'U.LOGIN_DATE',
                'C.CHARACTER_ID',
                'C.CHARACTER_INFO_ID',
            );
        $wheres = array(
                'U.STATUS' => 1,
                'U.USER_ID > ' => 0,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users U')
            ->join('users_characters C', 'C.CHARACTER_ID=U.CHARACTER_ID')
            ->where($wheres)
            ->like('U.EMAIL', $data['KEYWORD'])
            ->get();
        $return = $result->result_array();

        return $return;
    }

    public function selectSuggestFriends($data = array()) {
        $user_count = $this->db->count_all('users');
        $user_ids = array();
        for ($i = 0; $i < 50; $i++) {
            $user_id = rand(1, $user_count);

            if ($user_id == $data['USER_ID']) continue;

            $user_ids[] = $user_id;
        }

        $fields = array(
                'U.USER_ID',
                'U.EMAIL',
                'U.NICKNAME',
                'U.LEVEL',
                'U.AGREE_MESSAGE',
                'U.LOGIN_DATE',
                'R.SCORE',
                'C.CHARACTER_ID',
                'C.CHARACTER_INFO_ID',
                'C.LEVEL AS CHARACTER_LEVEL',
            );
        $wheres = array(
                'U.STATUS' => 1,
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('users U')
            ->join('users_characters C', 'C.CHARACTER_ID=U.CHARACTER_ID')
            ->join('leagues_ranking_' . LEAGUE_DATE . ' R', 'R.USER_ID=U.USER_ID', 'LEFT OUTER')
            ->where($wheres)
            ->where_in('U.USER_ID', $user_ids)
            ->where('U.USER_ID NOT IN (SELECT FRIEND_USER_ID FROM op_users_friends WHERE USER_ID=' . $data['USER_ID'] . ')', null, false)
            ->order_by('R.SCORE', 'DESC')
            ->limit(10)
            ->get();
        $return = $result->result_array();

        return $return;
    }

    public function selectFriendRequestCount($data = array()) {
        $wheres = array(
            'F.USER_ID' => $data['USER_ID'],
            'F.STATUS' => 0,
            'U.STATUS' => 1,
        );

        $count = $this->db
            ->from('users_friends F')
            ->join('users U', 'F.FRIEND_USER_ID=U.USER_ID')
            ->where($wheres)
            ->count_all_results();

        return $count;
    }

    public function insertFriend($data = array()) {
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'FRIEND_USER_ID' => $data['FRIEND_USER_ID'],
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'STATUS' => 2
            );

        $this->db->insert('users_friends', $insert);

        $insert = array(
                'USER_ID' => $data['FRIEND_USER_ID'],
                'FRIEND_USER_ID' => $data['USER_ID'],
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'STATUS' => 0
            );

        $this->db->insert('users_friends', $insert);
    }

    public function acceptFriend($data = array()) {
        $update = array(
                'STATUS' => 1
            );

        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'FRIEND_USER_ID' => $data['FRIEND_USER_ID'],
        );

        $this->db
            ->where($wheres)
            ->update('users_friends', $update);

        $wheres = array(
                'USER_ID' => $data['FRIEND_USER_ID'],
                'FRIEND_USER_ID' => $data['USER_ID'],
        );

        $this->db
            ->where($wheres)
            ->update('users_friends', $update);
    }

    public function updateFriend($data = array()) {
        $update = array();

        if (!empty($data['IS_PLAY'])) {
            $update['PLAY_DATE'] = date('Y-m-d H:i:s');
        }

        if (!empty($data['STATUS'])) {
            $update['STATUS'] = $data['STATUS'];
        }

        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'FRIEND_USER_ID' => $data['FRIEND_USER_ID'],
            );

        $this->db
            ->where($wheres)
            ->update('users_friends', $update);
    }

    public function deleteFriend($data = array()) {
        $update = array(
                'DELETE_DATE' => date('Y-m-d H:i:s'),
                'STATUS' => 3
            );

        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'FRIEND_USER_ID' => $data['FRIEND_USER_ID'],
            );

        $this->db
            ->where($wheres)
            ->update('users_friends', $update);
    }

    public function getFriendInviteData($data = array()) {
        $fields = array(
                'USER_ID',
                'INVITE_USER_ID',
                'INVITE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'INVITE_USER_ID' => $data['INVITE_USER_ID'],
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('invites')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function getFriendInvitesData($data = array()) {
        $fields = array(
                'USER_ID',
                'INVITE_USER_ID',
                'INVITE_DATE',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'INVITE_DATE > ' => date('Y-m-d H:i:s', strtotime('-' . INVITE_LIMIT_DAY . ' days')),
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('invites')
            ->where($wheres)
            ->get();
        $return = $result->result_array();

        return $return;
    }

    public function getFriendInviteTodayCountData($data = array()) {
        $fields = array(
                'COUNT(*) AS INVITE_COUNT',
            );
        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'DATE_FORMAT( INVITE_DATE, "%Y%m%d" ) =' => date('Ymd'),
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('invites')
            ->where($wheres)
            ->get();
        $return = $result->row_array();

        return $return;
    }

    public function addFriendInviteData($data = array()) {
        $insert = array(
                'USER_ID' => $data['USER_ID'],
                'INVITE_USER_ID' => $data['INVITE_USER_ID'],
                'INVITE_DATE' => date('Y-m-d H:i:s')
            );

        $this->db->insert('invites', $insert);
    }

    public function setFriendInviteData($data = array()) {
        $update = array(
                'INVITE_DATE' => date('Y-m-d H:i:s')
            );

        $wheres = array(
                'USER_ID' => $data['USER_ID'],
                'INVITE_USER_ID' => $data['INVITE_USER_ID'],
            );

        $this->db
            ->where($wheres)
            ->update('invites', $update);
    }
}