<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Notice_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectNotices($data = array()) {
        $fields = array(
            'NOTICE_ID',
            'TITLE',
            'CONTENT',
            'START_DATE',
            'END_DATE',
            'IS_SHOW',
        );
        $wheres = array(
            'IS_SHOW' => 1
        );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('notices')
            ->where('"' . date('Y-m-d H:i:s') . '" BETWEEN START_DATE AND END_DATE', null, false)
            ->where($wheres)
            ->order_by('NOTICE_ID', 'DESC')
            ->get();

        $return = array();
        foreach ($result->result_array() as $row) {
            $row['CONTENT'] = json_decode($row['CONTENT'], true);
            $remain = 12 - date('g');
            if ($remain == 0) $remain = 12;

            foreach ($row['CONTENT'] as $language => $content) {
                $row['CONTENT'][$language] = str_replace('{REMAINING_HOUR}', $remain, $content);
            }

            $return[] = $row;
        }

        return $return;
    }
}