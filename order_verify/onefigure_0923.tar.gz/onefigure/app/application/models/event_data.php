<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Event_data extends CI_Model {
    public function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function __destruct() {
        $this->db->close();
    }

    public function selectEvents($data = array()) {
        $fields = array(
                'EVENT_ID',
                'PROCESS_CODE',
                'TITLE',
                'EVENT_DETAIL',
                'START_DATE',
                'END_DATE',
            );
        $wheres = array(
                'PROCESS_CODE' => $data['PROCESS_CODE'],
                'IS_DELETE' => 0
            );

        $result = $this->db
            ->select(implode(', ', $fields))
            ->from('events')
            ->where($wheres)
            ->where('NOW() BETWEEN START_DATE AND END_DATE')
            ->get();
        $return = $result->result_array();

        return $return;
    }

    public function checkEventInProcess($data = array()) {
        $return = false;
        $eventRows = $this->selectEvents($data);

        foreach ($eventRows as $row) {
            if ($row['EVENT_ID'] == 4) {
                if ($this->uri->segment(1) != 'v12') continue;
            }

            $detail = json_decode($row['EVENT_DETAIL'], true);
            $data['EVENT_ID'] = $row['EVENT_ID'];

            // hourly
            if (isset($detail['SPOT_START_TIME']) && is_numeric($detail['SPOT_START_TIME'])) {
                if (date('G') < $detail['SPOT_START_TIME'] || date('G') > $detail['SPOT_END_TIME']) {
                    continue;
                }
            }

            if ($detail['REPEAT_CODE'] == 1) {  // total count
                $fields = array(
                        'COUNT(*) AS EVENT_COUNT',
                    );
                $wheres = array(
                        'EVENT_ID' => $data['EVENT_ID'],
                        'USER_ID' => $data['USER_ID']
                    );

                $result = $this->db
                    ->select(implode(', ', $fields))
                    ->from('events_users')
                    ->where($wheres)
                    ->get();
                $eventUserRow = $result->row_array();
                if (!isset($eventUserRow['EVENT_COUNT'])) $eventUserRow['EVENT_COUNT'] = 0;
                $eventUserRow['EVENT_COUNT']++;
            } else if ($detail['REPEAT_CODE'] == 2) {   // daily
                $fields = array(
                        'COUNT(*) AS EVENT_COUNT',
                    );
                $wheres = array(
                        'EVENT_ID' => $data['EVENT_ID'],
                        'USER_ID' => $data['USER_ID'],
                        'DATE_FORMAT( CREATE_DATE, "%Y%m%d" ) =' => date('Ymd')
                    );

                $result = $this->db
                    ->select(implode(', ', $fields))
                    ->from('events_users')
                    ->where($wheres)
                    ->get();
                $eventUserRow = $result->row_array();
                if (!isset($eventUserRow['EVENT_COUNT'])) $eventUserRow['EVENT_COUNT'] = 0;
                $eventUserRow['EVENT_COUNT']++;
            }

            if (($eventUserRow['EVENT_COUNT'] % $detail['REPEAT_COUNT']) == 0 && ($eventUserRow['EVENT_COUNT'] <= $detail['LIMIT_COUNT'] || $detail['LIMIT_COUNT'] == 0)) {

                if( is_numeric( $detail['GIFT_TYPE'])) {
                    $data['GIFT_TYPE'] = $detail['GIFT_TYPE'];
                    $data['ITEM_ID'] = $detail['ITEM_ID'];
                    $data['AMOUNT'] = $detail['AMOUNT'];

                    $this->insertEventMessage($data);

                }
                else if( $detail['GIFT_TYPE'] == 'ofdpm_event') {

                    $CI = &get_instance();
                    $message = array(
                        'SEND_USER_ID' => 0,
                        'RECEIVE_USER_ID' => $data['USER_ID'],
                        'GIFT_TYPE' => 6,
                        'ITEM_ID' => 0,
                        'TEXT_ID' => 7,
                        'AMOUNT' => 100,
                    );

                    $CI->Message_data->insertMessage($message);

                    processVIP( MINI_VIP_DURATION_SECS, $data, true);

                    $this->datainputoutput->set('MINI_VIP_DURATION_SECS'.$row['EVENT_ID'], count($eventRows));
                }

                $this->insertEventUser($data);
                $return = true;
            } else if (($eventUserRow['EVENT_COUNT'] % $detail['REPEAT_COUNT']) != 0) {
                $this->insertEventUser($data);
            } else {
            }
        }

        return $return;
    }

    public function insertEventUser($data = array()) {
        $insert = array(
                'EVENT_ID' => $data['EVENT_ID'],
                'USER_ID' => $data['USER_ID'],
                'CREATE_DATE' => date('Y-m-d H:i:s'),
            );

        $this->db->insert('events_users', $insert);
    }

    public function insertEventMessage($data = array()) {
        $gift = array(
            'TYPE' => $data['GIFT_TYPE'],
            'ITEM_ID' => $data['ITEM_ID'],
            'AMOUNT' => $data['AMOUNT'],
        );

        $insert = array(
                'SEND_USER_ID' => 0,
                'RECIEVE_USER_ID' => $data['USER_ID'],
                'EVENT_ID' => $data['EVENT_ID'],
                'GIFT' => json_encode($gift),
                'CREATE_DATE' => date('Y-m-d H:i:s'),
                'CREATE_IP' => $this->input->ip_address(),
                'IS_DELETE' => 0,
            );

        $this->db->insert('messages', $insert);
    }
}
