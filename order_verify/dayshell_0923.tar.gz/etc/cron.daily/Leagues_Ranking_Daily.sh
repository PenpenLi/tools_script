#!/bin/sh

NextDay=`date --date "1 day" +%Y%m%d`
TwoDay=`date --date "2 day" +%Y%m%d`
BackupDay=`date --date "7 day ago" +%Y%m%d`
echo ${BackupDay}

Dir="/mnt"
LogDir="/mnt/${BackupDay}"
DB_Pass=root123!
DB_Name=ofdp
Table_Name=op_leagues_ranking

mysql -uroot -p${DB_Pass} ofdp -e "
CREATE TABLE if not exists op_leagues_ranking_${NextDay} (
  USER_ID int(11) NOT NULL,
  GRADE int(11) NOT NULL,
  GROUP_ID int(11) NOT NULL,
  SCORE int(11) NOT NULL,
  REWARD_OK tinyint(4) NOT NULL,
  UNIQUE KEY USER_ID (USER_ID,GRADE,GROUP_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE if not exists op_leagues_ranking_${TwoDay} (
  USER_ID int(11) NOT NULL,
  GRADE int(11) NOT NULL,
  GROUP_ID int(11) NOT NULL,
  SCORE int(11) NOT NULL,
  REWARD_OK tinyint(4) NOT NULL,
  UNIQUE KEY USER_ID (USER_ID,GRADE,GROUP_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

"


#####Daily Create Dir#####
if [ ! -d ${Dir}/$Date ]
then
mkdir ${Dir}/$Date
fi


#####7Days Ago op_leagues_ranking Table Dump#####
#mysqldump -uroot -p${DB_Pass} --no-create-info --single-transaction ${DB_Name} ${Table_Name}_${BackupDay} > ${LogDir}/${Table_Name}_${BackupDay}.sql


#####7days ago Table drop#####
mysql -uroot -p${DB_Pass} ${DB_Name} -e"
Drop table if exists ${Table_Name}_${BackupDay}"

#####Log DB Data Trans#####
#expect -c"
#set timeout -1
#spawn scp -r -o StrictHostKeyChecking=no ${LogDir}/${Table_Name}_${BackupDay}.sql root@OFDP_Dev:/Data/BackupData/${BackupDay}/
#expect -re \"password:\"
#sleep 0.5
#send \"${Svr_Pass}\r\n\"
#interact
#expect eof
#"
                  
