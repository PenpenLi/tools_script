#!/bin/sh

PreDate=`date --date "1 days ago" +%Y%m%d`
NextDate=`date --date "+1 days" +%Y%m%d`
Date=`date +%Y%m%d`
Dir="/mnt"
LogDir="/mnt/${Date}"
DB_Pass=root123!
DB_Name=ofdp
#Svr_Pass=""
Table_Name=op_log_point

#####3일치 op_log_lottery 테이블 생성#####
NextDate1=`date --date "+1 days" +%Y%m%d`
NextDate2=`date --date "+2 days" +%Y%m%d`
NextDate3=`date --date "+3 days" +%Y%m%d`

CreDate=(${NextDate1} ${NextDate2} ${NextDate3})
CreDateCnt=${#CreDate[@]}
Cnt=0

while [ $Cnt -lt $CreDateCnt ]
do


mysql  -uroot -p${DB_Pass} ofdp -e "


CREATE TABLE if not exists ${Table_Name}_${CreDate[$Cnt]} (
  USER_ID int(11) NOT NULL,
  POINT_TYPE tinyint(4) NOT NULL,
  CATEGORY int(11) NOT NULL,
  POINT int(11) NOT NULL,
  CURRENT_POINT int(11) NOT NULL,
  CREATE_DATE datetime NOT NULL
) ENGINE=ARCHIVE DEFAULT CHARSET=utf8;

"

Cnt=`expr $Cnt + 1`
done

#####Daily Dir Create#####
if [ ! -d ${Dir}/$Date ]
then
mkdir ${Dir}/$Date
fi


chown -R mysql.mysql ${Dir}/$Date

#####Yesterday op_log_Pont Dump#####

mysqldump -uroot -p${DB_Pass} --no-create-info --single-transaction ${DB_Name} ${Table_Name}_${PreDate} > ${Dir}/${Date}/${Table_Name}_${PreDate}.sql

#####Yesterday table Drop#####
mysql  -uroot -p${DB_Pass} ofdp -e "
Drop table if exists ${Table_Name}_${PreDate}"

#####Log DB Data Trans#####
#expect -c"
#set timeout -1
#spawn scp -r -o StrictHostKeyChecking=no ${LogDir}/${Table_Name}_${PreDate}.sql root@OFDP_Dev:/Data/BackupData/${Date}/
#expect -re \"password:\"
#sleep 0.5
#send \"${Svr_Pass}\r\n\"
#interact
#expect eof
#"

