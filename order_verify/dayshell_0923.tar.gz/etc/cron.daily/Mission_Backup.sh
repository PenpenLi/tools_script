#!/bin/sh

PreDate=`date --date "1 days ago" +%Y%m%d`
NextDate=`date --date "+1 days" +%Y%m%d`
Date=`date +%Y%m%d`
Dir="/mnt"
LogDir="/mnt/${Date}"
DB_Pass=root123!
DB_Name=ofdp
Table_Name=op_users_missions

##### op_users_missions create table#####
NextDate1=`date --date "+1 days" +%Y%m%d`
NextDate2=`date --date "+2 days" +%Y%m%d`
NextDate3=`date --date "+3 days" +%Y%m%d`

CreDate=(${NextDate1} ${NextDate2} ${NextDate3})
CreDateCnt=${#CreDate[@]}
Cnt=0

while [ $Cnt -lt $CreDateCnt ]
do


mysql  -uroot -p${DB_Pass} ofdp -e "


CREATE TABLE if not exists ${Table_Name}_${CreDate[$Cnt]}  (
  MISSION_ID bigint(20) NOT NULL AUTO_INCREMENT,
  MISSION_INFO_ID int(11) NOT NULL,
  USER_ID int(11) NOT NULL,
  IS_CLEAR tinyint(4) NOT NULL,
  UPDATE_DATE datetime DEFAULT NULL,
  PRIMARY KEY (MISSION_ID),
  KEY USER_ID (USER_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

"

Cnt=`expr $Cnt + 1`
done

#####Create Dir#####
if [ ! -d ${Dir}/$Date ]
then
mkdir ${Dir}/$Date
fi

##########
chown -R mysql.mysql ${Dir}/$Date

#####Yester op_users_missions Table Dump#####
mysqldump -uroot -p${DB_Pass} --no-create-info --single-transaction ${DB_Name} ${Table_Name}_${PreDate} > ${LogDir}/${Table_Name}_${PreDate}.sql

#####Yesterday op_users_missions drop Table#####
mysql  -uroot -p${DB_Pass} ofdp -e "
Drop table if exists ${Table_Name}_${PreDate}"

#####Log DB Data Trans#####
#expect -c"
#set timeout -1
#spawn scp -r -o StrictHostKeyChecking=no ${LogDir}/${Table_Name}_${PreDate}.sql root@OFDP_Dev:/Data/BackupData/${Date}/
#expect -re \"password:\"
#sleep 0.5
#send \"${Svr_Pass}\r\n\"
#interact
#expect eof
#"

