#!/bin/sh

PreDate=`date --date "1 days ago" +%Y%m%d`
NextDate=`date --date "+1 days" +%Y%m%d`
Date=`date +%Y%m%d`
Dir="/mnt"
LogDir="/mnt/${Date}"
DB_Pass=root123!
DB_Name=ofdp
#Svr_Pass=""
Table_Name=op_log_game_start

#####op_log_game_start Create Table#####
NextDate1=`date --date "+1 days" +%Y%m%d`
NextDate2=`date --date "+2 days" +%Y%m%d`
NextDate3=`date --date "+3 days" +%Y%m%d`

CreDate=(${NextDate1} ${NextDate2} ${NextDate3})
CreDateCnt=${#CreDate[@]}
Cnt=0

while [ $Cnt -lt $CreDateCnt ]
do


mysql -uroot -p${DB_Pass} ofdp -e "

CREATE TABLE if not exists ${Table_Name}_${CreDate[$Cnt]} (
  PLAY_CODE bigint(20) NOT NULL,
  USER_ID int(11) NOT NULL,
  STAGE_ID int(11) NOT NULL COMMENT '0:Survival',
  LEVEL int(11) NOT NULL,
  \`CHARACTER\` varchar(4000) NOT NULL,
  SKILLS varchar(4000) NOT NULL,
  TREASURES varchar(4000) NOT NULL,
  ITEMS varchar(4000) NOT NULL,
  START_DATE datetime NOT NULL
) ENGINE=ARCHIVE DEFAULT CHARSET=utf8;

"

Cnt=`expr $Cnt + 1`
done

#####Daily Create Dir#####
if [ ! -d ${Dir}/$Date ]
then
mkdir ${Dir}/$Date
fi

##########
chown -R mysql.mysql ${Dir}/$Date

#####Yesterday Data Backup#####

mysqldump -uroot -p${DB_Pass} --no-create-info --single-transaction ${DB_Name} ${Table_Name}_${PreDate} > ${Dir}/${Date}/${Table_Name}_${PreDate}.sql

#####Yesterday Table Drop#####
mysql -uroot -p${DB_Pass} ofdp -e "
Drop table if exists ${Table_Name}_${PreDate}"

#####Log DB Data Trans#####
#expect -c"
#set timeout -1
#spawn scp -r -o StrictHostKeyChecking=no ${LogDir}/${Table_Name}_${PreDate}.sql root@OFDP_Dev:/Data/BackupData/${Date}/
#expect -re \"password:\"
#sleep 0.5
#send \"${Svr_Pass}\r\n\"
#interact
#expect eof
#"

