<?php

$db_ip = '127.0.0.1';

$db_user = 'root';

$db_pw = 'root123!';

?>
